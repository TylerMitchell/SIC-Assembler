
HashTable< InstructionSet > OPTAB(1000);
HashTable< Symbol > SYMTAB(1000);
HashTable< Directive > DTAB(100);
queue<Instruction> INSTRUCTIONLIST;
#define FRONT 0
#define BACK 1